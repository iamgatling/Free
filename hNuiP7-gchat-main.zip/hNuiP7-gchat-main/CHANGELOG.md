# Changelog

All notable changes to this project will be documented in this file.

> Thanks @psubramanian for the suggestion.

## [3.1.3] - 2024-05-29

### Fixed

- Fixed a regression from v3.1.2 where applications could not start in production environment. `@andreas.marblism`
