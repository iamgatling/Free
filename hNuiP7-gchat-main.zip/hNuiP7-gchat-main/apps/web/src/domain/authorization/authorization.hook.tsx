import { useCode as useCodeInternal } from './hooks/authorization.code.hook'

export namespace AuthorizationHook {
  export const useCode = useCodeInternal
}
