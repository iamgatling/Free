import { Module } from '@nestjs/common'
import { SocketModule } from '@server/libraries/socket'
import { AuthorizationDomainModule } from '@server/modules/authorization/domain'
import { NotificationDomainModule } from '../domain'

import { NotificationWorldChatMessageSubscriber } from './subscribers/notification.worldChatMessage.subscriber'

import { NotificationFriendRequestSubscriber } from './subscribers/notification.friendRequest.subscriber'

import { NotificationPrivateMessageSubscriber } from './subscribers/notification.privateMessage.subscriber'

import { NotificationContactSubscriber } from './subscribers/notification.contact.subscriber'

import { NotificationBlockSubscriber } from './subscribers/notification.block.subscriber'

import { NotificationReportSubscriber } from './subscribers/notification.report.subscriber'

import { NotificationGroupChatSubscriber } from './subscribers/notification.groupChat.subscriber'

import { NotificationGroupChatMemberSubscriber } from './subscribers/notification.groupChatMember.subscriber'

import { NotificationGroupChatMessageSubscriber } from './subscribers/notification.groupChatMessage.subscriber'

@Module({
  imports: [AuthorizationDomainModule, NotificationDomainModule, SocketModule],
  providers: [
    NotificationWorldChatMessageSubscriber,

    NotificationFriendRequestSubscriber,

    NotificationPrivateMessageSubscriber,

    NotificationContactSubscriber,

    NotificationBlockSubscriber,

    NotificationReportSubscriber,

    NotificationGroupChatSubscriber,

    NotificationGroupChatMemberSubscriber,

    NotificationGroupChatMessageSubscriber,
  ],
  exports: [],
})
export class NotificationInfrastructureModule {}
