import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import { Block, BlockDomainFacade } from '@server/modules/block/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { BlockApplicationEvent } from './block.application.event'
import { BlockCreateDto, BlockUpdateDto } from './block.dto'

@Controller('/v1/blocks')
export class BlockController {
  constructor(
    private eventService: EventService,
    private blockDomainFacade: BlockDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.blockDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: BlockCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.blockDomainFacade.create(body)

    await this.eventService.emit<BlockApplicationEvent.BlockCreated.Payload>(
      BlockApplicationEvent.BlockCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:blockId')
  async findOne(@Param('blockId') blockId: string, @Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.blockDomainFacade.findOneByIdOrFail(
      blockId,
      queryOptions,
    )

    return item
  }

  @Patch('/:blockId')
  async update(
    @Param('blockId') blockId: string,
    @Body() body: BlockUpdateDto,
  ) {
    const item = await this.blockDomainFacade.findOneByIdOrFail(blockId)

    const itemUpdated = await this.blockDomainFacade.update(
      item,
      body as Partial<Block>,
    )
    return itemUpdated
  }

  @Delete('/:blockId')
  async delete(@Param('blockId') blockId: string) {
    const item = await this.blockDomainFacade.findOneByIdOrFail(blockId)

    await this.blockDomainFacade.delete(item)

    return item
  }
}
