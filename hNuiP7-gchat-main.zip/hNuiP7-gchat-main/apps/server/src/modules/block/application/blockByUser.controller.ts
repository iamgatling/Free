import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { BlockDomainFacade } from '@server/modules/block/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { BlockApplicationEvent } from './block.application.event'
import { BlockCreateDto } from './block.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class BlockByUserController {
  constructor(
    private userDomainFacade: UserDomainFacade,

    private blockDomainFacade: BlockDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/blocker/:blockerId/blocks')
  async findManyBlockerId(
    @Param('blockerId') blockerId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.userDomainFacade.findOneByIdOrFail(blockerId)

    const items = await this.blockDomainFacade.findManyByBlocker(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/blocker/:blockerId/blocks')
  async createByBlockerId(
    @Param('blockerId') blockerId: string,
    @Body() body: BlockCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, blockerId }

    const item = await this.blockDomainFacade.create(valuesUpdated)

    await this.eventService.emit<BlockApplicationEvent.BlockCreated.Payload>(
      BlockApplicationEvent.BlockCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/blocked/:blockedId/blocks')
  async findManyBlockedId(
    @Param('blockedId') blockedId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.userDomainFacade.findOneByIdOrFail(blockedId)

    const items = await this.blockDomainFacade.findManyByBlocked(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/blocked/:blockedId/blocks')
  async createByBlockedId(
    @Param('blockedId') blockedId: string,
    @Body() body: BlockCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, blockedId }

    const item = await this.blockDomainFacade.create(valuesUpdated)

    await this.eventService.emit<BlockApplicationEvent.BlockCreated.Payload>(
      BlockApplicationEvent.BlockCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
