import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { BlockDomainModule } from '../domain'
import { BlockController } from './block.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { BlockByUserController } from './blockByUser.controller'

@Module({
  imports: [AuthenticationDomainModule, BlockDomainModule, UserDomainModule],
  controllers: [BlockController, BlockByUserController],
  providers: [],
})
export class BlockApplicationModule {}
