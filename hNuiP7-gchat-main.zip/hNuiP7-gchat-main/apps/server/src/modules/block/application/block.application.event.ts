export namespace BlockApplicationEvent {
  export namespace BlockCreated {
    export const key = 'block.application.block.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
