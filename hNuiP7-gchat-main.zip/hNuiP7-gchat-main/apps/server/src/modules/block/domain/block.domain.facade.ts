import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { Block } from './block.model'

import { User } from '../../user/domain'

@Injectable()
export class BlockDomainFacade {
  constructor(
    @InjectRepository(Block)
    private repository: Repository<Block>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<Block>): Promise<Block> {
    return this.repository.save(values)
  }

  async update(item: Block, values: Partial<Block>): Promise<Block> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: Block): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<Block> = {},
  ): Promise<Block[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<Block> = {},
  ): Promise<Block> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByBlocker(
    item: User,
    queryOptions: RequestHelper.QueryOptions<Block> = {},
  ): Promise<Block[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('blocker')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        blockerId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

  async findManyByBlocked(
    item: User,
    queryOptions: RequestHelper.QueryOptions<Block> = {},
  ): Promise<Block[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('blocked')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        blockedId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
