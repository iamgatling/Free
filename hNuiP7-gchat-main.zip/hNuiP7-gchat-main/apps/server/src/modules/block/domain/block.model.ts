import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

@Entity()
export class Block {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  blockerId: string

  @ManyToOne(() => User, parent => parent.blocksAsBlocker)
  @JoinColumn({ name: 'blockerId' })
  blocker?: User

  @Column({})
  blockedId: string

  @ManyToOne(() => User, parent => parent.blocksAsBlocked)
  @JoinColumn({ name: 'blockedId' })
  blocked?: User

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
