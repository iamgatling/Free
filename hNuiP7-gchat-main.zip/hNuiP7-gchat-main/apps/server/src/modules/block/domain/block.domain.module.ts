import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { BlockDomainFacade } from './block.domain.facade'
import { Block } from './block.model'

@Module({
  imports: [TypeOrmModule.forFeature([Block]), DatabaseHelperModule],
  providers: [BlockDomainFacade, BlockDomainFacade],
  exports: [BlockDomainFacade],
})
export class BlockDomainModule {}
