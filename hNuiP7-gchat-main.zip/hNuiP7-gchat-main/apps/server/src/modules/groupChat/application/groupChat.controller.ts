import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  GroupChat,
  GroupChatDomainFacade,
} from '@server/modules/groupChat/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { GroupChatApplicationEvent } from './groupChat.application.event'
import { GroupChatCreateDto, GroupChatUpdateDto } from './groupChat.dto'

@Controller('/v1/groupChats')
export class GroupChatController {
  constructor(
    private eventService: EventService,
    private groupChatDomainFacade: GroupChatDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.groupChatDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: GroupChatCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.groupChatDomainFacade.create(body)

    await this.eventService.emit<GroupChatApplicationEvent.GroupChatCreated.Payload>(
      GroupChatApplicationEvent.GroupChatCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:groupChatId')
  async findOne(
    @Param('groupChatId') groupChatId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.groupChatDomainFacade.findOneByIdOrFail(
      groupChatId,
      queryOptions,
    )

    return item
  }

  @Patch('/:groupChatId')
  async update(
    @Param('groupChatId') groupChatId: string,
    @Body() body: GroupChatUpdateDto,
  ) {
    const item = await this.groupChatDomainFacade.findOneByIdOrFail(groupChatId)

    const itemUpdated = await this.groupChatDomainFacade.update(
      item,
      body as Partial<GroupChat>,
    )
    return itemUpdated
  }

  @Delete('/:groupChatId')
  async delete(@Param('groupChatId') groupChatId: string) {
    const item = await this.groupChatDomainFacade.findOneByIdOrFail(groupChatId)

    await this.groupChatDomainFacade.delete(item)

    return item
  }
}
