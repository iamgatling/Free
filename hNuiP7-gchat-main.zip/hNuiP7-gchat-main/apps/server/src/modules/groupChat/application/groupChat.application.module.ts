import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { GroupChatDomainModule } from '../domain'
import { GroupChatController } from './groupChat.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { GroupChatByUserController } from './groupChatByUser.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    GroupChatDomainModule,

    UserDomainModule,
  ],
  controllers: [GroupChatController, GroupChatByUserController],
  providers: [],
})
export class GroupChatApplicationModule {}
