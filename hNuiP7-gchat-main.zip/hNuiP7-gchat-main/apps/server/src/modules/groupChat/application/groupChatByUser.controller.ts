import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { GroupChatDomainFacade } from '@server/modules/groupChat/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { GroupChatApplicationEvent } from './groupChat.application.event'
import { GroupChatCreateDto } from './groupChat.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class GroupChatByUserController {
  constructor(
    private userDomainFacade: UserDomainFacade,

    private groupChatDomainFacade: GroupChatDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/creator/:creatorId/groupChats')
  async findManyCreatorId(
    @Param('creatorId') creatorId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.userDomainFacade.findOneByIdOrFail(creatorId)

    const items = await this.groupChatDomainFacade.findManyByCreator(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/creator/:creatorId/groupChats')
  async createByCreatorId(
    @Param('creatorId') creatorId: string,
    @Body() body: GroupChatCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, creatorId }

    const item = await this.groupChatDomainFacade.create(valuesUpdated)

    await this.eventService.emit<GroupChatApplicationEvent.GroupChatCreated.Payload>(
      GroupChatApplicationEvent.GroupChatCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
