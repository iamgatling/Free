export namespace GroupChatApplicationEvent {
  export namespace GroupChatCreated {
    export const key = 'groupChat.application.groupChat.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
