import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { GroupChatDomainFacade } from './groupChat.domain.facade'
import { GroupChat } from './groupChat.model'

@Module({
  imports: [TypeOrmModule.forFeature([GroupChat]), DatabaseHelperModule],
  providers: [GroupChatDomainFacade, GroupChatDomainFacade],
  exports: [GroupChatDomainFacade],
})
export class GroupChatDomainModule {}
