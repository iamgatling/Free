import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { GroupChatMember } from '../../../modules/groupChatMember/domain'

import { GroupChatMessage } from '../../../modules/groupChatMessage/domain'

@Entity()
export class GroupChat {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  name: string

  @Column({})
  timestamp: string

  @Column({})
  creatorId: string

  @ManyToOne(() => User, parent => parent.groupChatsAsCreator)
  @JoinColumn({ name: 'creatorId' })
  creator?: User

  @OneToMany(() => GroupChatMember, child => child.groupChat)
  groupChatMembers?: GroupChatMember[]

  @OneToMany(() => GroupChatMessage, child => child.groupChat)
  groupChatMessages?: GroupChatMessage[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
