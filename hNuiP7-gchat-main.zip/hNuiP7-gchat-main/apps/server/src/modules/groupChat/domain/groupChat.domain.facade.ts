import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { GroupChat } from './groupChat.model'

import { User } from '../../user/domain'

@Injectable()
export class GroupChatDomainFacade {
  constructor(
    @InjectRepository(GroupChat)
    private repository: Repository<GroupChat>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<GroupChat>): Promise<GroupChat> {
    return this.repository.save(values)
  }

  async update(
    item: GroupChat,
    values: Partial<GroupChat>,
  ): Promise<GroupChat> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: GroupChat): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<GroupChat> = {},
  ): Promise<GroupChat[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<GroupChat> = {},
  ): Promise<GroupChat> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByCreator(
    item: User,
    queryOptions: RequestHelper.QueryOptions<GroupChat> = {},
  ): Promise<GroupChat[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('creator')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        creatorId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
