import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  WorldChatMessage,
  WorldChatMessageDomainFacade,
} from '@server/modules/worldChatMessage/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { WorldChatMessageApplicationEvent } from './worldChatMessage.application.event'
import {
  WorldChatMessageCreateDto,
  WorldChatMessageUpdateDto,
} from './worldChatMessage.dto'

@Controller('/v1/worldChatMessages')
export class WorldChatMessageController {
  constructor(
    private eventService: EventService,
    private worldChatMessageDomainFacade: WorldChatMessageDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.worldChatMessageDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: WorldChatMessageCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.worldChatMessageDomainFacade.create(body)

    await this.eventService.emit<WorldChatMessageApplicationEvent.WorldChatMessageCreated.Payload>(
      WorldChatMessageApplicationEvent.WorldChatMessageCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:worldChatMessageId')
  async findOne(
    @Param('worldChatMessageId') worldChatMessageId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.worldChatMessageDomainFacade.findOneByIdOrFail(
      worldChatMessageId,
      queryOptions,
    )

    return item
  }

  @Patch('/:worldChatMessageId')
  async update(
    @Param('worldChatMessageId') worldChatMessageId: string,
    @Body() body: WorldChatMessageUpdateDto,
  ) {
    const item =
      await this.worldChatMessageDomainFacade.findOneByIdOrFail(
        worldChatMessageId,
      )

    const itemUpdated = await this.worldChatMessageDomainFacade.update(
      item,
      body as Partial<WorldChatMessage>,
    )
    return itemUpdated
  }

  @Delete('/:worldChatMessageId')
  async delete(@Param('worldChatMessageId') worldChatMessageId: string) {
    const item =
      await this.worldChatMessageDomainFacade.findOneByIdOrFail(
        worldChatMessageId,
      )

    await this.worldChatMessageDomainFacade.delete(item)

    return item
  }
}
