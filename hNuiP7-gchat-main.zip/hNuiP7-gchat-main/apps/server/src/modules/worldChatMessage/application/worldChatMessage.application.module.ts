import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { WorldChatMessageDomainModule } from '../domain'
import { WorldChatMessageController } from './worldChatMessage.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { WorldChatMessageByUserController } from './worldChatMessageByUser.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    WorldChatMessageDomainModule,

    UserDomainModule,
  ],
  controllers: [WorldChatMessageController, WorldChatMessageByUserController],
  providers: [],
})
export class WorldChatMessageApplicationModule {}
