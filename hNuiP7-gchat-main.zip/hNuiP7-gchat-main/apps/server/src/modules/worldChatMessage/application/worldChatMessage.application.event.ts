export namespace WorldChatMessageApplicationEvent {
  export namespace WorldChatMessageCreated {
    export const key = 'worldChatMessage.application.worldChatMessage.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
