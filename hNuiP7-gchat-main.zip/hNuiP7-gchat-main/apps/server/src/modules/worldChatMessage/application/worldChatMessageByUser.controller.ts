import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { WorldChatMessageDomainFacade } from '@server/modules/worldChatMessage/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { WorldChatMessageApplicationEvent } from './worldChatMessage.application.event'
import { WorldChatMessageCreateDto } from './worldChatMessage.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class WorldChatMessageByUserController {
  constructor(
    private userDomainFacade: UserDomainFacade,

    private worldChatMessageDomainFacade: WorldChatMessageDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/user/:userId/worldChatMessages')
  async findManyUserId(
    @Param('userId') userId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.userDomainFacade.findOneByIdOrFail(userId)

    const items = await this.worldChatMessageDomainFacade.findManyByUser(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/user/:userId/worldChatMessages')
  async createByUserId(
    @Param('userId') userId: string,
    @Body() body: WorldChatMessageCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, userId }

    const item = await this.worldChatMessageDomainFacade.create(valuesUpdated)

    await this.eventService.emit<WorldChatMessageApplicationEvent.WorldChatMessageCreated.Payload>(
      WorldChatMessageApplicationEvent.WorldChatMessageCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
