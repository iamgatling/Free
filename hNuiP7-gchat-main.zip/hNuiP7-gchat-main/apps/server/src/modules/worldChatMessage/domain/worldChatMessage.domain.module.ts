import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { WorldChatMessageDomainFacade } from './worldChatMessage.domain.facade'
import { WorldChatMessage } from './worldChatMessage.model'

@Module({
  imports: [TypeOrmModule.forFeature([WorldChatMessage]), DatabaseHelperModule],
  providers: [WorldChatMessageDomainFacade, WorldChatMessageDomainFacade],
  exports: [WorldChatMessageDomainFacade],
})
export class WorldChatMessageDomainModule {}
