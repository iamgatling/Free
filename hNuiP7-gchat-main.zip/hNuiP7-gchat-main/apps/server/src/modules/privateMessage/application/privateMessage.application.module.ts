import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { PrivateMessageDomainModule } from '../domain'
import { PrivateMessageController } from './privateMessage.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { PrivateMessageByUserController } from './privateMessageByUser.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    PrivateMessageDomainModule,

    UserDomainModule,
  ],
  controllers: [PrivateMessageController, PrivateMessageByUserController],
  providers: [],
})
export class PrivateMessageApplicationModule {}
