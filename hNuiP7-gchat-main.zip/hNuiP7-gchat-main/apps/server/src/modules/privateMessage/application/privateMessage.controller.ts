import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  PrivateMessage,
  PrivateMessageDomainFacade,
} from '@server/modules/privateMessage/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { PrivateMessageApplicationEvent } from './privateMessage.application.event'
import {
  PrivateMessageCreateDto,
  PrivateMessageUpdateDto,
} from './privateMessage.dto'

@Controller('/v1/privateMessages')
export class PrivateMessageController {
  constructor(
    private eventService: EventService,
    private privateMessageDomainFacade: PrivateMessageDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.privateMessageDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: PrivateMessageCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.privateMessageDomainFacade.create(body)

    await this.eventService.emit<PrivateMessageApplicationEvent.PrivateMessageCreated.Payload>(
      PrivateMessageApplicationEvent.PrivateMessageCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:privateMessageId')
  async findOne(
    @Param('privateMessageId') privateMessageId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.privateMessageDomainFacade.findOneByIdOrFail(
      privateMessageId,
      queryOptions,
    )

    return item
  }

  @Patch('/:privateMessageId')
  async update(
    @Param('privateMessageId') privateMessageId: string,
    @Body() body: PrivateMessageUpdateDto,
  ) {
    const item =
      await this.privateMessageDomainFacade.findOneByIdOrFail(privateMessageId)

    const itemUpdated = await this.privateMessageDomainFacade.update(
      item,
      body as Partial<PrivateMessage>,
    )
    return itemUpdated
  }

  @Delete('/:privateMessageId')
  async delete(@Param('privateMessageId') privateMessageId: string) {
    const item =
      await this.privateMessageDomainFacade.findOneByIdOrFail(privateMessageId)

    await this.privateMessageDomainFacade.delete(item)

    return item
  }
}
