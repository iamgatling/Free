export namespace PrivateMessageApplicationEvent {
  export namespace PrivateMessageCreated {
    export const key = 'privateMessage.application.privateMessage.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
