import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { PrivateMessageDomainFacade } from '@server/modules/privateMessage/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { PrivateMessageApplicationEvent } from './privateMessage.application.event'
import { PrivateMessageCreateDto } from './privateMessage.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class PrivateMessageByUserController {
  constructor(
    private userDomainFacade: UserDomainFacade,

    private privateMessageDomainFacade: PrivateMessageDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/sender/:senderId/privateMessages')
  async findManySenderId(
    @Param('senderId') senderId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.userDomainFacade.findOneByIdOrFail(senderId)

    const items = await this.privateMessageDomainFacade.findManyBySender(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/sender/:senderId/privateMessages')
  async createBySenderId(
    @Param('senderId') senderId: string,
    @Body() body: PrivateMessageCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, senderId }

    const item = await this.privateMessageDomainFacade.create(valuesUpdated)

    await this.eventService.emit<PrivateMessageApplicationEvent.PrivateMessageCreated.Payload>(
      PrivateMessageApplicationEvent.PrivateMessageCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/receiver/:receiverId/privateMessages')
  async findManyReceiverId(
    @Param('receiverId') receiverId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.userDomainFacade.findOneByIdOrFail(receiverId)

    const items = await this.privateMessageDomainFacade.findManyByReceiver(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/receiver/:receiverId/privateMessages')
  async createByReceiverId(
    @Param('receiverId') receiverId: string,
    @Body() body: PrivateMessageCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, receiverId }

    const item = await this.privateMessageDomainFacade.create(valuesUpdated)

    await this.eventService.emit<PrivateMessageApplicationEvent.PrivateMessageCreated.Payload>(
      PrivateMessageApplicationEvent.PrivateMessageCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
