import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { PrivateMessageDomainFacade } from './privateMessage.domain.facade'
import { PrivateMessage } from './privateMessage.model'

@Module({
  imports: [TypeOrmModule.forFeature([PrivateMessage]), DatabaseHelperModule],
  providers: [PrivateMessageDomainFacade, PrivateMessageDomainFacade],
  exports: [PrivateMessageDomainFacade],
})
export class PrivateMessageDomainModule {}
