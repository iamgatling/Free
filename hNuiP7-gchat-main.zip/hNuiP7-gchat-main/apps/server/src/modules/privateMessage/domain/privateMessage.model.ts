import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Report } from '../../../modules/report/domain'

@Entity()
export class PrivateMessage {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  message: string

  @Column({})
  timestamp: string

  @Column({})
  isDeleted: boolean

  @Column({})
  senderId: string

  @ManyToOne(() => User, parent => parent.privateMessagesAsSender)
  @JoinColumn({ name: 'senderId' })
  sender?: User

  @Column({})
  receiverId: string

  @ManyToOne(() => User, parent => parent.privateMessagesAsReceiver)
  @JoinColumn({ name: 'receiverId' })
  receiver?: User

  @OneToMany(() => Report, child => child.reportedMessage)
  reportsAsReportedMessage?: Report[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
