import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Notification } from '../../../modules/notification/domain'

import { WorldChatMessage } from '../../../modules/worldChatMessage/domain'

import { FriendRequest } from '../../../modules/friendRequest/domain'

import { PrivateMessage } from '../../../modules/privateMessage/domain'

import { Contact } from '../../../modules/contact/domain'

import { Block } from '../../../modules/block/domain'

import { Report } from '../../../modules/report/domain'

import { GroupChat } from '../../../modules/groupChat/domain'

import { GroupChatMember } from '../../../modules/groupChatMember/domain'

import { GroupChatMessage } from '../../../modules/groupChatMessage/domain'

export enum UserStatus {
  VERIFIED = 'VERIFIED',
  CREATED = 'CREATED',
}

@Entity()
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true, unique: true })
  email?: string

  @Column({ nullable: true })
  name?: string

  @Column({ nullable: true })
  pictureUrl?: string

  @Column({ nullable: true, select: false })
  stripeCustomerId?: string

  @Column({ nullable: true, select: false })
  password?: string

  @Column({ enum: UserStatus, default: UserStatus.VERIFIED })
  status: UserStatus

  @OneToMany(() => WorldChatMessage, child => child.user)
  worldChatMessages?: WorldChatMessage[]

  @OneToMany(() => FriendRequest, child => child.sender)
  friendRequestsAsSender?: FriendRequest[]

  @OneToMany(() => FriendRequest, child => child.receiver)
  friendRequestsAsReceiver?: FriendRequest[]

  @OneToMany(() => PrivateMessage, child => child.sender)
  privateMessagesAsSender?: PrivateMessage[]

  @OneToMany(() => PrivateMessage, child => child.receiver)
  privateMessagesAsReceiver?: PrivateMessage[]

  @OneToMany(() => Contact, child => child.user)
  contacts?: Contact[]

  @OneToMany(() => Contact, child => child.contact)
  contactsAsContact?: Contact[]

  @OneToMany(() => Block, child => child.blocker)
  blocksAsBlocker?: Block[]

  @OneToMany(() => Block, child => child.blocked)
  blocksAsBlocked?: Block[]

  @OneToMany(() => Report, child => child.reporter)
  reportsAsReporter?: Report[]

  @OneToMany(() => Report, child => child.reportedUser)
  reportsAsReportedUser?: Report[]

  @OneToMany(() => GroupChat, child => child.creator)
  groupChatsAsCreator?: GroupChat[]

  @OneToMany(() => GroupChatMember, child => child.user)
  groupChatMembers?: GroupChatMember[]

  @OneToMany(() => GroupChatMessage, child => child.user)
  groupChatMessages?: GroupChatMessage[]

  @OneToMany(() => Notification, notification => notification.user)
  notifications?: Notification[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
