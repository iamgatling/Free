import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { GroupChatMemberDomainFacade } from './groupChatMember.domain.facade'
import { GroupChatMember } from './groupChatMember.model'

@Module({
  imports: [TypeOrmModule.forFeature([GroupChatMember]), DatabaseHelperModule],
  providers: [GroupChatMemberDomainFacade, GroupChatMemberDomainFacade],
  exports: [GroupChatMemberDomainFacade],
})
export class GroupChatMemberDomainModule {}
