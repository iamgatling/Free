import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { GroupChatMemberDomainModule } from '../domain'
import { GroupChatMemberController } from './groupChatMember.controller'

import { GroupChatDomainModule } from '../../../modules/groupChat/domain'

import { GroupChatMemberByGroupChatController } from './groupChatMemberByGroupChat.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { GroupChatMemberByUserController } from './groupChatMemberByUser.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    GroupChatMemberDomainModule,

    GroupChatDomainModule,

    UserDomainModule,
  ],
  controllers: [
    GroupChatMemberController,

    GroupChatMemberByGroupChatController,

    GroupChatMemberByUserController,
  ],
  providers: [],
})
export class GroupChatMemberApplicationModule {}
