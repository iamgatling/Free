import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  GroupChatMember,
  GroupChatMemberDomainFacade,
} from '@server/modules/groupChatMember/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { GroupChatMemberApplicationEvent } from './groupChatMember.application.event'
import {
  GroupChatMemberCreateDto,
  GroupChatMemberUpdateDto,
} from './groupChatMember.dto'

@Controller('/v1/groupChatMembers')
export class GroupChatMemberController {
  constructor(
    private eventService: EventService,
    private groupChatMemberDomainFacade: GroupChatMemberDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.groupChatMemberDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: GroupChatMemberCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.groupChatMemberDomainFacade.create(body)

    await this.eventService.emit<GroupChatMemberApplicationEvent.GroupChatMemberCreated.Payload>(
      GroupChatMemberApplicationEvent.GroupChatMemberCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:groupChatMemberId')
  async findOne(
    @Param('groupChatMemberId') groupChatMemberId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.groupChatMemberDomainFacade.findOneByIdOrFail(
      groupChatMemberId,
      queryOptions,
    )

    return item
  }

  @Patch('/:groupChatMemberId')
  async update(
    @Param('groupChatMemberId') groupChatMemberId: string,
    @Body() body: GroupChatMemberUpdateDto,
  ) {
    const item =
      await this.groupChatMemberDomainFacade.findOneByIdOrFail(
        groupChatMemberId,
      )

    const itemUpdated = await this.groupChatMemberDomainFacade.update(
      item,
      body as Partial<GroupChatMember>,
    )
    return itemUpdated
  }

  @Delete('/:groupChatMemberId')
  async delete(@Param('groupChatMemberId') groupChatMemberId: string) {
    const item =
      await this.groupChatMemberDomainFacade.findOneByIdOrFail(
        groupChatMemberId,
      )

    await this.groupChatMemberDomainFacade.delete(item)

    return item
  }
}
