export namespace GroupChatMemberApplicationEvent {
  export namespace GroupChatMemberCreated {
    export const key = 'groupChatMember.application.groupChatMember.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
