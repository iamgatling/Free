import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { GroupChatMemberDomainFacade } from '@server/modules/groupChatMember/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { GroupChatMemberApplicationEvent } from './groupChatMember.application.event'
import { GroupChatMemberCreateDto } from './groupChatMember.dto'

import { GroupChatDomainFacade } from '../../groupChat/domain'

@Controller('/v1/groupChats')
export class GroupChatMemberByGroupChatController {
  constructor(
    private groupChatDomainFacade: GroupChatDomainFacade,

    private groupChatMemberDomainFacade: GroupChatMemberDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/groupChat/:groupChatId/groupChatMembers')
  async findManyGroupChatId(
    @Param('groupChatId') groupChatId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent =
      await this.groupChatDomainFacade.findOneByIdOrFail(groupChatId)

    const items = await this.groupChatMemberDomainFacade.findManyByGroupChat(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/groupChat/:groupChatId/groupChatMembers')
  async createByGroupChatId(
    @Param('groupChatId') groupChatId: string,
    @Body() body: GroupChatMemberCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, groupChatId }

    const item = await this.groupChatMemberDomainFacade.create(valuesUpdated)

    await this.eventService.emit<GroupChatMemberApplicationEvent.GroupChatMemberCreated.Payload>(
      GroupChatMemberApplicationEvent.GroupChatMemberCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
