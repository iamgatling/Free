import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { GroupChatMessageDomainFacade } from './groupChatMessage.domain.facade'
import { GroupChatMessage } from './groupChatMessage.model'

@Module({
  imports: [TypeOrmModule.forFeature([GroupChatMessage]), DatabaseHelperModule],
  providers: [GroupChatMessageDomainFacade, GroupChatMessageDomainFacade],
  exports: [GroupChatMessageDomainFacade],
})
export class GroupChatMessageDomainModule {}
