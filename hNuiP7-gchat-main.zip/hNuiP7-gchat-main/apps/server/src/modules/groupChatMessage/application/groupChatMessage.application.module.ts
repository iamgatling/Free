import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { GroupChatMessageDomainModule } from '../domain'
import { GroupChatMessageController } from './groupChatMessage.controller'

import { GroupChatDomainModule } from '../../../modules/groupChat/domain'

import { GroupChatMessageByGroupChatController } from './groupChatMessageByGroupChat.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { GroupChatMessageByUserController } from './groupChatMessageByUser.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    GroupChatMessageDomainModule,

    GroupChatDomainModule,

    UserDomainModule,
  ],
  controllers: [
    GroupChatMessageController,

    GroupChatMessageByGroupChatController,

    GroupChatMessageByUserController,
  ],
  providers: [],
})
export class GroupChatMessageApplicationModule {}
