import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { GroupChatMessageDomainFacade } from '@server/modules/groupChatMessage/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { GroupChatMessageApplicationEvent } from './groupChatMessage.application.event'
import { GroupChatMessageCreateDto } from './groupChatMessage.dto'

import { GroupChatDomainFacade } from '../../groupChat/domain'

@Controller('/v1/groupChats')
export class GroupChatMessageByGroupChatController {
  constructor(
    private groupChatDomainFacade: GroupChatDomainFacade,

    private groupChatMessageDomainFacade: GroupChatMessageDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/groupChat/:groupChatId/groupChatMessages')
  async findManyGroupChatId(
    @Param('groupChatId') groupChatId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent =
      await this.groupChatDomainFacade.findOneByIdOrFail(groupChatId)

    const items = await this.groupChatMessageDomainFacade.findManyByGroupChat(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/groupChat/:groupChatId/groupChatMessages')
  async createByGroupChatId(
    @Param('groupChatId') groupChatId: string,
    @Body() body: GroupChatMessageCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, groupChatId }

    const item = await this.groupChatMessageDomainFacade.create(valuesUpdated)

    await this.eventService.emit<GroupChatMessageApplicationEvent.GroupChatMessageCreated.Payload>(
      GroupChatMessageApplicationEvent.GroupChatMessageCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
