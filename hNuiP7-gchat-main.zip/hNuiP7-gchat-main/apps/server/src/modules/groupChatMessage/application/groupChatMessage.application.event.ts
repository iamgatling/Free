export namespace GroupChatMessageApplicationEvent {
  export namespace GroupChatMessageCreated {
    export const key = 'groupChatMessage.application.groupChatMessage.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
