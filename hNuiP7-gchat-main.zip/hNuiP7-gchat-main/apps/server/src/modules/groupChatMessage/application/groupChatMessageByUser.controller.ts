import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { GroupChatMessageDomainFacade } from '@server/modules/groupChatMessage/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { GroupChatMessageApplicationEvent } from './groupChatMessage.application.event'
import { GroupChatMessageCreateDto } from './groupChatMessage.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class GroupChatMessageByUserController {
  constructor(
    private userDomainFacade: UserDomainFacade,

    private groupChatMessageDomainFacade: GroupChatMessageDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/user/:userId/groupChatMessages')
  async findManyUserId(
    @Param('userId') userId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.userDomainFacade.findOneByIdOrFail(userId)

    const items = await this.groupChatMessageDomainFacade.findManyByUser(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/user/:userId/groupChatMessages')
  async createByUserId(
    @Param('userId') userId: string,
    @Body() body: GroupChatMessageCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, userId }

    const item = await this.groupChatMessageDomainFacade.create(valuesUpdated)

    await this.eventService.emit<GroupChatMessageApplicationEvent.GroupChatMessageCreated.Payload>(
      GroupChatMessageApplicationEvent.GroupChatMessageCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
