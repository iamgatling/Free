import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  GroupChatMessage,
  GroupChatMessageDomainFacade,
} from '@server/modules/groupChatMessage/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { GroupChatMessageApplicationEvent } from './groupChatMessage.application.event'
import {
  GroupChatMessageCreateDto,
  GroupChatMessageUpdateDto,
} from './groupChatMessage.dto'

@Controller('/v1/groupChatMessages')
export class GroupChatMessageController {
  constructor(
    private eventService: EventService,
    private groupChatMessageDomainFacade: GroupChatMessageDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.groupChatMessageDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: GroupChatMessageCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.groupChatMessageDomainFacade.create(body)

    await this.eventService.emit<GroupChatMessageApplicationEvent.GroupChatMessageCreated.Payload>(
      GroupChatMessageApplicationEvent.GroupChatMessageCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:groupChatMessageId')
  async findOne(
    @Param('groupChatMessageId') groupChatMessageId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.groupChatMessageDomainFacade.findOneByIdOrFail(
      groupChatMessageId,
      queryOptions,
    )

    return item
  }

  @Patch('/:groupChatMessageId')
  async update(
    @Param('groupChatMessageId') groupChatMessageId: string,
    @Body() body: GroupChatMessageUpdateDto,
  ) {
    const item =
      await this.groupChatMessageDomainFacade.findOneByIdOrFail(
        groupChatMessageId,
      )

    const itemUpdated = await this.groupChatMessageDomainFacade.update(
      item,
      body as Partial<GroupChatMessage>,
    )
    return itemUpdated
  }

  @Delete('/:groupChatMessageId')
  async delete(@Param('groupChatMessageId') groupChatMessageId: string) {
    const item =
      await this.groupChatMessageDomainFacade.findOneByIdOrFail(
        groupChatMessageId,
      )

    await this.groupChatMessageDomainFacade.delete(item)

    return item
  }
}
