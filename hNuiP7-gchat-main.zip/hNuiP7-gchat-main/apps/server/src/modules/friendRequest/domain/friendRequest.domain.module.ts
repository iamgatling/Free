import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { FriendRequestDomainFacade } from './friendRequest.domain.facade'
import { FriendRequest } from './friendRequest.model'

@Module({
  imports: [TypeOrmModule.forFeature([FriendRequest]), DatabaseHelperModule],
  providers: [FriendRequestDomainFacade, FriendRequestDomainFacade],
  exports: [FriendRequestDomainFacade],
})
export class FriendRequestDomainModule {}
