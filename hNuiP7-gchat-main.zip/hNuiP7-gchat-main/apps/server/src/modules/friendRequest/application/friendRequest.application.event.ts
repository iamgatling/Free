export namespace FriendRequestApplicationEvent {
  export namespace FriendRequestCreated {
    export const key = 'friendRequest.application.friendRequest.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
