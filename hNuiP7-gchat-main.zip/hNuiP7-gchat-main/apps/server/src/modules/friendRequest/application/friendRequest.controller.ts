import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  FriendRequest,
  FriendRequestDomainFacade,
} from '@server/modules/friendRequest/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { FriendRequestApplicationEvent } from './friendRequest.application.event'
import {
  FriendRequestCreateDto,
  FriendRequestUpdateDto,
} from './friendRequest.dto'

@Controller('/v1/friendRequests')
export class FriendRequestController {
  constructor(
    private eventService: EventService,
    private friendRequestDomainFacade: FriendRequestDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.friendRequestDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: FriendRequestCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.friendRequestDomainFacade.create(body)

    await this.eventService.emit<FriendRequestApplicationEvent.FriendRequestCreated.Payload>(
      FriendRequestApplicationEvent.FriendRequestCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:friendRequestId')
  async findOne(
    @Param('friendRequestId') friendRequestId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.friendRequestDomainFacade.findOneByIdOrFail(
      friendRequestId,
      queryOptions,
    )

    return item
  }

  @Patch('/:friendRequestId')
  async update(
    @Param('friendRequestId') friendRequestId: string,
    @Body() body: FriendRequestUpdateDto,
  ) {
    const item =
      await this.friendRequestDomainFacade.findOneByIdOrFail(friendRequestId)

    const itemUpdated = await this.friendRequestDomainFacade.update(
      item,
      body as Partial<FriendRequest>,
    )
    return itemUpdated
  }

  @Delete('/:friendRequestId')
  async delete(@Param('friendRequestId') friendRequestId: string) {
    const item =
      await this.friendRequestDomainFacade.findOneByIdOrFail(friendRequestId)

    await this.friendRequestDomainFacade.delete(item)

    return item
  }
}
