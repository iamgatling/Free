import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { FriendRequestDomainModule } from '../domain'
import { FriendRequestController } from './friendRequest.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { FriendRequestByUserController } from './friendRequestByUser.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    FriendRequestDomainModule,

    UserDomainModule,
  ],
  controllers: [FriendRequestController, FriendRequestByUserController],
  providers: [],
})
export class FriendRequestApplicationModule {}
