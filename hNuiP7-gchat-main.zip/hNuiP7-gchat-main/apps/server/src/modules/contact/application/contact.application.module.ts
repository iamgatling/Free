import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ContactDomainModule } from '../domain'
import { ContactController } from './contact.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { ContactByUserController } from './contactByUser.controller'

@Module({
  imports: [AuthenticationDomainModule, ContactDomainModule, UserDomainModule],
  controllers: [ContactController, ContactByUserController],
  providers: [],
})
export class ContactApplicationModule {}
