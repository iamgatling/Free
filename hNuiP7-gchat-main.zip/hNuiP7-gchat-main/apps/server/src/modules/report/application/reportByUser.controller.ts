import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { ReportDomainFacade } from '@server/modules/report/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { ReportApplicationEvent } from './report.application.event'
import { ReportCreateDto } from './report.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class ReportByUserController {
  constructor(
    private userDomainFacade: UserDomainFacade,

    private reportDomainFacade: ReportDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/reporter/:reporterId/reports')
  async findManyReporterId(
    @Param('reporterId') reporterId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.userDomainFacade.findOneByIdOrFail(reporterId)

    const items = await this.reportDomainFacade.findManyByReporter(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/reporter/:reporterId/reports')
  async createByReporterId(
    @Param('reporterId') reporterId: string,
    @Body() body: ReportCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, reporterId }

    const item = await this.reportDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ReportApplicationEvent.ReportCreated.Payload>(
      ReportApplicationEvent.ReportCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/reportedUser/:reportedUserId/reports')
  async findManyReportedUserId(
    @Param('reportedUserId') reportedUserId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.userDomainFacade.findOneByIdOrFail(reportedUserId)

    const items = await this.reportDomainFacade.findManyByReportedUser(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/reportedUser/:reportedUserId/reports')
  async createByReportedUserId(
    @Param('reportedUserId') reportedUserId: string,
    @Body() body: ReportCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, reportedUserId }

    const item = await this.reportDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ReportApplicationEvent.ReportCreated.Payload>(
      ReportApplicationEvent.ReportCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
