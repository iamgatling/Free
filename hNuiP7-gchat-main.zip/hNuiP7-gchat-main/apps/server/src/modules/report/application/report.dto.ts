import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class ReportCreateDto {
  @IsString()
  @IsNotEmpty()
  reason: string

  @IsString()
  @IsNotEmpty()
  timestamp: string

  @IsString()
  @IsOptional()
  reporterId?: string

  @IsString()
  @IsOptional()
  reportedUserId?: string

  @IsString()
  @IsOptional()
  reportedMessageId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class ReportUpdateDto {
  @IsString()
  @IsOptional()
  reason?: string

  @IsString()
  @IsOptional()
  timestamp?: string

  @IsString()
  @IsOptional()
  reporterId?: string

  @IsString()
  @IsOptional()
  reportedUserId?: string

  @IsString()
  @IsOptional()
  reportedMessageId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
