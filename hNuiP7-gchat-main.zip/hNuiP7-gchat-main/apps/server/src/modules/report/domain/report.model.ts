import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { PrivateMessage } from '../../../modules/privateMessage/domain'

@Entity()
export class Report {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  reason: string

  @Column({})
  timestamp: string

  @Column({})
  reporterId: string

  @ManyToOne(() => User, parent => parent.reportsAsReporter)
  @JoinColumn({ name: 'reporterId' })
  reporter?: User

  @Column({})
  reportedUserId: string

  @ManyToOne(() => User, parent => parent.reportsAsReportedUser)
  @JoinColumn({ name: 'reportedUserId' })
  reportedUser?: User

  @Column({})
  reportedMessageId: string

  @ManyToOne(() => PrivateMessage, parent => parent.reportsAsReportedMessage)
  @JoinColumn({ name: 'reportedMessageId' })
  reportedMessage?: PrivateMessage

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
